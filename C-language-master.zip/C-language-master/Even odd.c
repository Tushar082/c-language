#include <stdio.h> 
#include<conio.h> 
 void main()  
{  
    int n;    
printf("enter a number:");    
scanf("%d",&n);     
if(n%2==0)
{    
printf("the number is even");    
}    
else
{    
printf("the number is odd");    
}     
    getch();
    }
