#include<stdio.h>
#include<conio.h>
void main()
{
	int n=0;
	while(1)
	{
		printf("\n %d",n);
		n++;
	}
getch();
}
