#include<stdio.h>
#include<conio.h>
void main()
{
	int a,b;
printf("enter any number");
scanf("%d",&a);
printf("enter any number");
scanf("%d",&b);
a>b?printf("%d",a);
printf("%d",b);
getch();
}
