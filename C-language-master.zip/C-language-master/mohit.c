#include<stdio.h>

void main()
{

    int n;
        for(n=10;n<=100;n++)
        {
          printf("%d ,",n);
        }
getchar();
}
